# Project completion and validation status

## Included
- Tkinter Windows desktop interface
- UVC camera capture requesting 3840x2160 MJPG where supported
- Image-folder input for camera-independent testing
- Page quadrilateral detection and perspective correction
- Document, colour and grayscale enhancement
- Optional left/right spread splitting
- Capture list, undo, remove, individual image save
- JPEG session export with JSON manifest
- Multi-page PDF export
- Windows launch/build scripts
- GitHub Actions test/build workflow and GitHub Pages preview

## Checks completed in this environment
- `python -m pytest -q`: 6 passed
- Python sample images opened and processed successfully
- Source modules are included in the repository package

## Not claimed as verified
- Physical UVC webcam operation
- 3840x2160 capture on a particular webcam (the app requests this mode but the device/driver decides the negotiated mode)
- Windows 10/11 GUI and PyInstaller executable launch
- GitHub Actions or GitHub Pages deployment

## Final hardware acceptance
On the target Windows computer, follow `docs/installation.md` and complete every item in its functional acceptance checklist. The static Pages site is only a project overview; the scanner itself is a local desktop application.
