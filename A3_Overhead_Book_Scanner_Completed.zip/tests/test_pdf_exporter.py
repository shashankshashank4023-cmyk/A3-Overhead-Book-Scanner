from pathlib import Path
import cv2
import numpy as np
from pdf_exporter import export_pdf


def test_pdf_export_creates_multi_page_file(tmp_path: Path):
    pages = [np.full((80, 100, 3), 255, dtype=np.uint8), np.zeros((80, 100, 3), dtype=np.uint8)]
    target = tmp_path / 'test.pdf'
    export_pdf(pages, target)
    assert target.exists() and target.stat().st_size > 500


def test_pdf_export_rejects_empty_pages(tmp_path):
    import pytest
    with pytest.raises(ValueError):
        export_pdf([], tmp_path / 'empty.pdf')
