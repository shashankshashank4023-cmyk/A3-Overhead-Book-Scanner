@echo off
setlocal
cd /d "%~dp0"
py -3 -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements-dev.txt
pyinstaller --noconfirm --clean --windowed --name A3OverheadBookScanner --collect-all cv2 main.py
if errorlevel 1 exit /b 1
echo Build complete: dist\A3OverheadBookScanner\A3OverheadBookScanner.exe
endlocal
