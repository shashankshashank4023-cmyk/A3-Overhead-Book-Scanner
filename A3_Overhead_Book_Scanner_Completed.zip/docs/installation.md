# Windows installation and field validation

## Install
1. Install 64-bit Python 3.10–3.12 and select **Add Python to PATH**.
2. Extract the project to a writable folder such as `C:\A3OverheadBookScanner`.
3. Run `run_windows.bat`; allow Windows camera access when prompted.
4. Connect the UVC camera directly to a USB 3 port where possible.

## Verify camera mode
Start the camera. The status line should report the negotiated resolution. If it is not 3840×2160, check the camera's supported modes, cable, USB port, driver, and other apps that may have locked the camera. OpenCV cannot force unsupported hardware modes.

## Functional acceptance checklist
- [ ] App launches without a Python exception.
- [ ] Camera opens and live preview updates.
- [ ] Reported camera resolution matches the device's expected mode.
- [ ] Capture detects a page and corrects perspective under normal lighting.
- [ ] Folder mode can process sample images without a webcam.
- [ ] Dual-page split creates two page images for a landscape spread.
- [ ] Undo and remove selected page work.
- [ ] Individual JPEG/PNG and session JPEG/JSON export work.
- [ ] Multi-page PDF opens and contains all captured pages.
- [ ] Packaged executable launches on a clean Windows machine.

## Troubleshooting
- **Camera unavailable:** close Camera/Teams/Zoom, check Settings > Privacy & security > Camera, reconnect USB, then try another camera index by changing `Camera()` in `main.py`.
- **Low resolution:** verify camera specifications and USB 3 connection; the app requests 4K but cannot override device limits.
- **Poor detection:** improve contrast and lighting, reduce background clutter, keep all page corners visible, and avoid page curl.
- **PDF export fails:** choose a writable output location and ensure sufficient disk space.
