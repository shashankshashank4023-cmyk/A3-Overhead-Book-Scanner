# GitHub deployment

This repository uses GitHub Actions for tests, a Windows build artifact and a static GitHub Pages project preview.

## Automated tests and Windows build
The workflow `.github/workflows/tests.yml` runs pytest on Ubuntu and Windows. On Windows it also packages the app using PyInstaller. Download the `A3OverheadBookScanner-Windows` artifact from the successful Actions run.

## Static preview
The workflow `.github/workflows/pages.yml` deploys `preview/` to GitHub Pages. If the first run reports Pages is not enabled, open **Settings → Pages**, select **GitHub Actions** as the build and deployment source, then rerun the workflow.

Expected URL: `https://shashankshashank4023-cmyk.github.io/A3-Overhead-Book-Scanner-/`.

## Desktop app vs preview
GitHub Pages only hosts the static information page. The actual scanner remains a Windows desktop program because it needs direct access to a locally connected UVC camera.
